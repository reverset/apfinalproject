package game.ecs;

public class RequireException extends RuntimeException {

	public RequireException(String string) {
		super(string);
	}

}
