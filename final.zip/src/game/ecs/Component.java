package game.ecs;

public interface Component {
	
}
