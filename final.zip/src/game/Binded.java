package game;

import game.ecs.Entity;

public interface Binded {
    void unbind(Entity entity);
}
