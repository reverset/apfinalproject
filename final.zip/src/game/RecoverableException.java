package game;

public class RecoverableException extends RuntimeException {
    
}
