package game;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

import com.raylib.Jaylib;
import com.raylib.Raylib;

import game.ecs.Entity;
import game.ecs.comps.Transform;

public class GameLoop {
	public static final int SCREEN_WIDTH = 850;
	public static final int SCREEN_HEIGHT = 450;

	private static final ArrayList<Entity> entities = new ArrayList<>();
	private static final Queue<Runnable> deferments = new LinkedList<>();

	private static Entity mainCamera;
	private static Camera mainCameraSystem;

	private static Raylib.RenderTexture renderTexture;
	private static Raylib.Rectangle screenRect;

	private static Shader postProcesShader = null;

	public static Camera getMainCamera() {
		return mainCameraSystem;
	}

	public static Entity getMainCameraEntity() {
		return mainCamera;
	}

	public static void setPostProcessShader(Shader shader) {
		postProcesShader = shader;
	}

	public static void disablePostProcessShader() {
		postProcesShader = null;
	}

	public static void setMainCamera(Entity entity) {
		mainCamera = entity;
		mainCameraSystem = mainCamera.getSystem(Camera.class).orElseThrow(() -> new RuntimeException("Missing Camera system when setting a new Camera entity."));
	}
	
	public static <T extends Entity> T track(T entity) {
		entities.add(entity);
		entity.ready();
		return entity;
	}

	public static boolean isPresent(Entity entity) {
		return entities.contains(entity);
	}

	public static void destroy(Entity entity) {
		entity.destroy();
		entities.remove(entity);
	}
	
	public static Iterator<Entity> getEntitiesIterator() {
		return entities.iterator();
	}

	public static void defer(Runnable action) {
		deferments.add(action);
	}
	
	public static void init() {
		Raylib.SetConfigFlags(Raylib.FLAG_VSYNC_HINT);
		Raylib.SetTraceLogLevel(Raylib.LOG_WARNING);
		Raylib.InitWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Game");

		setMainCamera(Camera.makeEntity(
			new Transform(), new CameraSettings(Vec2.screen().divide(2), 1)
		));

		renderTexture = Raylib.LoadRenderTexture(SCREEN_WIDTH, SCREEN_HEIGHT);
		screenRect = new Raylib.Rectangle().x(0).y(0).width(SCREEN_WIDTH).height(-SCREEN_HEIGHT);
	}
	
	public static void quit() {
		Raylib.CloseWindow();
	}
	
	public static void runBlocking() {
		while (!Raylib.WindowShouldClose()) {
			frameUpdate();
			renderUpdate();
			runAllDeferred();
			manageCleanupQueue();
		}
		deinit();
	}
	
	public static void deinit() {
		if (Raylib.IsWindowReady()) {			
			Raylib.CloseWindow();
		}
		System.gc();
		manageCleanupQueue();
	}

	public static Vec2 getMousePosition() {
		return new Vec2(
			Raylib.GetMouseX(),
			Raylib.GetMouseY()
		).screenToWorldEq();
	}
	
	private static void frameUpdate() {
		getEntitiesIterator().forEachRemaining(Entity::frame);
	}
	
	private static void renderUpdate() {
		Raylib.BeginTextureMode(renderTexture);

		Raylib.ClearBackground(Jaylib.BLACK);
		
		Raylib.BeginMode2D(mainCameraSystem.getPointer());
		
		getEntitiesIterator().forEachRemaining(Entity::render);
		
		Raylib.EndMode2D();
		Raylib.DrawFPS(15, 15);
		
		Raylib.EndTextureMode();
		
		Raylib.BeginDrawing();

		if (postProcesShader != null) postProcesShader.activate();
		
		Raylib.DrawTextureRec(renderTexture.texture(), screenRect, Vec2.zero().getPointer(), Jaylib.WHITE);
		
		if (postProcesShader != null) postProcesShader.deactivate();
		Raylib.EndDrawing();
	}
	
	private static void manageCleanupQueue() {
		Runnable action = null;
		while ((action = Janitor.poll()) != null) {
			action.run();
		}
	}

	private static void runAllDeferred() {
		new PollingIterator<>(deferments).forEachRemaining(Runnable::run);
	}
}
