package game;

import game.ecs.Component;
import com.raylib.Raylib;
import com.raylib.Jaylib;

public class Shader implements Component {
    private final Raylib.Shader internal;    
    
    public Shader(String path) {
        internal = Jaylib.LoadShader("default.vert", path);
        Janitor.register(this, () -> Raylib.UnloadShader(internal));
    }

    public void activate() {
        Raylib.BeginShaderMode(internal);
    }

    public void deactivate() {
        Raylib.EndShaderMode();
    }

    public Raylib.Shader getPointer() {
        return internal;
    }
}
