package game.core.rendering;

import game.Color;
import game.Vec2;
import game.ecs.Component;

import com.raylib.Raylib;

public class Rect implements Component {
    public int width;
    public int height;
    public Color color;
    
    public Rect(int width, int height, Color color) {
        this.width = width;
        this.height = height;
        this.color = color;
    }
    
    public boolean overlaps(Vec2 position, Vec2 otherPosition, Rect other) {
        var rect = raylibFromPosition(position);
        var otherR = other.raylibFromPosition(otherPosition);
        boolean result = Raylib.CheckCollisionRecs(rect, otherR);

        rect.close();
        otherR.close();

        return result;
    }

    protected Raylib.Rectangle raylibFromPosition(Vec2 pos) {
        return new Raylib.Rectangle().x(pos.x).y(pos.y).width(width).height(height);
    }
}
