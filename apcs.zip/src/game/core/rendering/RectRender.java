package game.core.rendering;

import game.ecs.ECSystem;
import game.ecs.comps.Transform;

import com.raylib.Raylib;

public class RectRender extends ECSystem {
    private Rect rect;
    private Transform trans;

    @Override
    public void setup() {
        rect = require(Rect.class);
        trans = require(Transform.class);
    }

    @Override
    public void render() {
        Raylib.DrawRectangle(trans.position.xInt(), trans.position.yInt(), rect.width, rect.height, rect.color.getPointer());
    }
    
}
