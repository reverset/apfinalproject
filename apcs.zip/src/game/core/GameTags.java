package game.core;

public enum GameTags {
    PLAYER,
    ENEMY,
    BULLET,
}
