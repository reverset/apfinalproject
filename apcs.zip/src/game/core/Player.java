package game.core;

import java.time.Duration;

import game.Color;
import game.GameLoop;
import game.ImmutableColor;
import game.RemoveAfter;
import game.Vec2;
import game.core.rendering.Rect;
import game.core.rendering.RectRender;
import game.ecs.ECSystem;
import game.ecs.Entity;
import game.ecs.comps.Transform;

public class Player extends ECSystem implements Controllable {
    public static Entity makeEntity() {
        return new Entity("Player")
            .addComponent(new Transform())
            .addComponent(new Health(100))
            .addComponent(new Rect(30, 30, new ImmutableColor(0, 200, 255, 255)))
            .addComponent(new Tangible())
            .register(new RectRender())
            .register(new Physics())
            .register(new Player())
            .register(new Controller<>(Player.class));
    }

    private Tangible tangible;
    private Physics physics;
    private Transform trans;

    @Override
    public void setup() {
        tangible = require(Tangible.class);
        physics = requireSystem(Physics.class);
        trans = require(Transform.class);
    }

    @Override
    public void frame() {
        tangible.velocity.moveTowardsEq(new Vec2(), 20 * delta());
    }

    private void fireBullet() {
        Vec2 direction = trans.position.directionTo(GameLoop.getMousePosition());

        GameLoop.defer(() -> {
            GameLoop.track(new Entity("Bullet")
                .addComponent(trans.clone())
                .addComponent(() -> {
                    var tangible = new Tangible();
                    tangible.velocity = direction.multiply(100);
                    return tangible;
                })
                .addComponent(new Rect(10, 10, Color.RED))
                .register(new Physics())
                .register(new RectRender())
                .register(new RemoveAfter(Duration.ofSeconds(1)))
                .register(new Bullet(entity)));
        });
    }

    @Override
    public void controlledClickOnce() {
        fireBullet();
    }

    @Override
    public void controlledLeftOnce() {
        tangible.velocity.x = 0;
        physics.impulse(Vec2.left().multiply(100));
    }

    @Override
    public void controlledRightOnce() {
        tangible.velocity.x = 0;
        physics.impulse(Vec2.right().multiply(100));
    }

    @Override
    public void controlledLeft() {
       physics.applyForce(Vec2.left().multiply(100));
    }

    @Override
    public void controlledRight() {
        physics.applyForce(Vec2.right().multiply(100));
    }

    @Override
    public void controlledDownOnce() {
        tangible.velocity.y = 0;
        physics.impulse(Vec2.down().multiply(100));
    }

    @Override
    public void controlledDown() {
        physics.applyForce(Vec2.down().multiply(100));
    }
    
    @Override
    public void controlledUpOnce() {
        tangible.velocity.y = 0;
        physics.impulse(Vec2.up().multiply(100));
    }

    @Override
    public void controlledUp() {
        physics.applyForce(Vec2.up().multiply(100));
    }
    
}
