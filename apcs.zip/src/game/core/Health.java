package game.core;

import game.Signal;
import game.ecs.Component;

public class Health implements Component {
    private int health;

    public Health(int maxHp) {
        health = maxHp;
    }

    public final Signal<Integer> onDamage = new Signal<>();

    public void damage(int dmg) {
        health -= dmg;
        onDamage.emit(dmg);
    }

    public int getHealth() {
        return health;
    }
    
}
