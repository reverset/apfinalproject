package game.core;

public interface Controllable {
    default void controlledLeft() {};
    default void controlledLeftOnce() {};
    
    default void controlledRight() {};
    default void controlledRightOnce() {};
    
    default void controlledUp() {};
    default void controlledUpOnce() {};

    default void controlledDown() {};
    default void controlledDownOnce() {};

    default void controlledClick() {};
    default void controlledClickOnce() {};
}
