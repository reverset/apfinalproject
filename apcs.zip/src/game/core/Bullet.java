package game.core;

import game.ecs.ECSystem;
import game.ecs.Entity;
import game.ecs.comps.Transform;

public class Bullet extends ECSystem {
    private enum Tag {
        BULLET,
    }
    public Entity owner;

    private Transform trans;
    private Tangible tangible;

    public Bullet(Entity owner) {
        this.owner = owner;
    }

    @Override
    public void setup() {
        trans = require(Transform.class);
        tangible = require(Tangible.class);

        entity.addTag(Tag.BULLET);

        tangible.onCollision.listen((otherPhysics) -> {
            if (otherPhysics.entity != owner && !otherPhysics.entity.hasTag(Tag.BULLET)) {
                otherPhysics.entity.getComponent(Health.class).ifPresent((health) -> health.damage(10));
            }
        }, entity);
    }

    @Override
    public void destroy() {
        tangible.onCollision.unlinkAllFromEntity(entity);
    }
}
