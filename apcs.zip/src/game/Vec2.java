package game;

import com.raylib.Raylib;

public class Vec2 {
	
	private final Raylib.Vector2 internal;
	
	public float x;
	public float y;
	
	public static Vec2 up() {
		return new Vec2(0, -1);
	}
	
	public static Vec2 down() {
		return new Vec2(0, 1);
	}
	
	public static Vec2 right() {
		return new Vec2(1, 0);
	}
	
	public static Vec2 left() {
		return new Vec2(-1, 0);
	}

	public static Vec2 zero() {
		return new Vec2();
	}

	public static Vec2 screen() {
		return new Vec2(
			Raylib.GetScreenWidth(),
			Raylib.GetScreenHeight()
		);
	}
	
	
	public Vec2(float x, float y, Raylib.Vector2 internal) {
		this.internal = internal;
		this.x = x;
		this.y = y;
		internal.x(x).y(y);
		
		Janitor.register(this, internal::close);
	}

	public Vec2(Raylib.Vector2 internal) { // TODO: cleanup repetitiveness eventually
		this.internal = internal;
		this.x = internal.x();
		this.y = internal.y();
		Janitor.register(this, internal::close);
	}
	
	public Vec2(float x, float y) {
		this(x, y, new Raylib.Vector2());
	}
	
	public Vec2() {
		this(0, 0);
	}
	
	public int xInt() {
		return (int)x;
	}
	public int yInt() {
		return (int)y;
	}
	
	public float dot(Vec2 other) {
		return x * other.x + y * other.y;
	}
	
	public float magnitude() {
		return (float) Math.sqrt(x*x + y*y);
	}
	
	public Vec2 normalize() {
		return divide(magnitude());
	}
	
	public Vec2 divide(Vec2 divisor) {
		return new Vec2(x / divisor.x, y / divisor.y);
	}
	
	public Vec2 divide(float divisor) {
		return new Vec2(x / divisor, y / divisor);
	}
	
	public Vec2 multiply(Vec2 other) {
		return new Vec2(x * other.x, y * other.y);
	}
	
	public Vec2 multiply(float scalar) {
		return new Vec2(x * scalar, y * scalar);
	}
	
	public Vec2 add(Vec2 other) {
		return new Vec2(x + other.x, y + other.y);
	}

	public Vec2 add(float scalar) {
		return new Vec2(x + scalar, y + scalar);
	}

	public void addEq(Vec2 other) {
		x += other.x;
		y += other.y;
	}

	public Vec2 minus(Vec2 other) {
		return new Vec2(x - other.x, y - other.y);
	}

	public Vec2 clamp(Vec2 minimums, Vec2 maximums) {
		return new Vec2(
			MoreMath.clamp(x, minimums.x, maximums.x), 
			MoreMath.clamp(y, minimums.y, maximums.y));
	}

	public void clampEq(float minX, float minY, float maxX, float maxY) {
		x = MoreMath.clamp(x, minX, maxX);
		y = MoreMath.clamp(y, minY, maxY);
	}

	public Vec2 moveTowards(Vec2 other, float delta) {
		return new Vec2(
			MoreMath.moveTowards(x, other.x, delta),
			MoreMath.moveTowards(y, other.y, delta)
		);
	}

	public void moveTowardsEq(Vec2 other, float delta) {
		x = MoreMath.moveTowards(x, other.x, delta);
		y = MoreMath.moveTowards(y, other.y, delta);
	}

	public Vec2 screenToWorld() {
		return new Vec2(Raylib.GetScreenToWorld2D(getPointer(), GameLoop.getMainCamera().getPointer()));
	}

	public Vec2 screenToWorldEq() {
		try (var v = Raylib.GetScreenToWorld2D(getPointer(), GameLoop.getMainCamera().getPointer())) {
			x = v.x();
			y = v.y();
		}
		return this;
	}

	public Vec2 directionTo(Vec2 other) {
		return (other.minus(this)).normalize();
	}

	public float getAngle() {
		return (float) Math.atan2(y, x);
	}

	public Vec2 fromAngle(float angle) {
		return new Vec2((float) Math.cos(angle), (float) Math.sin(angle));
	}

	public Vec2 clone() {
		return new Vec2(x, y);
	}

	@Override
	public String toString() {
		return "Vec2(" + x + ", " + y + ")";
	}
	
	public Raylib.Vector2 getPointer() {
		internal.x(x).y(y);
		return internal;
	}

	public Raylib.Vector2 getPointerNoUpdate() {
		return internal;
	}
}
