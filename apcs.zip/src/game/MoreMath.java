package game;

public class MoreMath {
    public static float clamp(float val, float min, float max) {
        float v = Math.max(val, min);
        return Math.min(v, max);
    }

    public static float moveTowards(float val, float desired, float delta) {
        if (Math.abs(val - desired) <= delta) return desired;

        return val + Math.signum(desired - val) * delta;
    }
}
