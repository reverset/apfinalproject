package game;

import game.ecs.Component;

public class CameraSettings implements Component {
    Vec2 offset;
    float zoom;

    public CameraSettings(Vec2 offset, float zoom) {
        this.offset = offset;
        this.zoom = zoom;
    }
}
