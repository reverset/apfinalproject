package game;

import com.raylib.Raylib;

import game.ecs.Entity;
import game.ecs.comps.Transform;
import game.core.Physics;
import game.core.Player;
import game.core.Tangible;
import game.core.rendering.Rect;
import game.core.rendering.RectRender;
import game.ecs.Component;
import game.ecs.ECSystem;

public class Game {
	public static void main(String[] args) { // Everything might be a bit over engineered...
		GameLoop.init();
		GameLoop.setPostProcessShader(new Shader("bloom.frag"));
		
		GameLoop.track(Player.makeEntity());
		
		GameLoop.runBlocking();
	}
	
}
